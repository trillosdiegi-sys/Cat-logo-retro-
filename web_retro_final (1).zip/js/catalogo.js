
const camisetas=[];
for(let i=1;i<=170;i++){
  camisetas.push({
    nombre:`Camiseta Retro ${i}`,
    temporada:`Año ${1970+(i%50)}`,
    equipo:`Equipo ${i%20+1}`,
    foto:`img/placeholder${i%10+1}.jpg`,
    url:"#",
    descripcion:`Descripción de la camiseta retro ${i}`
  });
}
let currentPage=1; const itemsPerPage=20; let filtered=[...camisetas];
const catalogo=document.getElementById('catalogo');
const pageInfo=document.getElementById('pageInfo');
const prevPage=document.getElementById('prevPage');
const nextPage=document.getElementById('nextPage');
const searchInput=document.getElementById('search');
const filterEquipo=document.getElementById('filterEquipo');
const filterTemporada=document.getElementById('filterTemporada');
const carritoCount=document.getElementById('carrito-count');
let carrito=JSON.parse(localStorage.getItem('carrito'))||[];
carritoCount.textContent=carrito.length;
const equipos=[...new Set(camisetas.map(c=>c.equipo))];
equipos.forEach(e=>filterEquipo.innerHTML+=`<option value="${e}">${e}</option>`);
const temporadas=[...new Set(camisetas.map(c=>c.temporada))];
temporadas.forEach(t=>filterTemporada.innerHTML+=`<option value="${t}">${t}</option>`);
function mostrarPagina(page){
  catalogo.innerHTML='';
  const start=(page-1)*itemsPerPage; const end=start+itemsPerPage;
  filtered.slice(start,end).forEach(c=>{
    const card=document.createElement('div'); card.className='card';
    card.innerHTML=`<img src="${c.foto}" alt="${c.nombre}"><div class="team">${c.nombre}</div><div class="season">${c.temporada}</div><div class="desc">${c.descripcion}</div><a href="${c.url}" class="buy" target="_blank">Ver producto</a><button class="buy" onclick="addCarrito('${c.nombre}')">Añadir al carrito</button>`;
    catalogo.appendChild(card);
  });
  pageInfo.textContent=`Página ${currentPage} de ${Math.ceil(filtered.length/itemsPerPage)}`;
}
function addCarrito(nombre){carrito.push(nombre); localStorage.setItem('carrito',JSON.stringify(carrito)); carritoCount.textContent=carrito.length;}
prevPage.onclick=()=>{if(currentPage>1){currentPage--;mostrarPagina(currentPage);}};
nextPage.onclick=()=>{if(currentPage<Math.ceil(filtered.length/itemsPerPage)){currentPage++;mostrarPagina(currentPage);}};
searchInput.oninput=()=>{filtrar();};
filterEquipo.onchange=()=>{filtrar();};
filterTemporada.onchange=()=>{filtrar();};
function filtrar(){
  const search=searchInput.value.toLowerCase();
  const eq=filterEquipo.value; const temp=filterTemporada.value;
  filtered=camisetas.filter(c=>c.nombre.toLowerCase().includes(search)&&(eq==''||c.equipo==eq)&&(temp==''||c.temporada==temp));
  currentPage=1; mostrarPagina(currentPage);
}
mostrarPagina(currentPage);
